package com.org.bebas.utils;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;
import com.github.dozermapper.core.loader.api.BeanMappingBuilder;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static com.github.dozermapper.core.loader.api.TypeMappingOptions.mapEmptyString;
import static com.github.dozermapper.core.loader.api.TypeMappingOptions.mapNull;

/**
 * Dozer Bean复制工具
 *
 * @Version V1.0.0
 */
public class MapperUtil {

    private static final Mapper DEFAULT_MAPPER;
    
    /**
     * 缓存不同配置的Mapper实例
     */
    private static final ConcurrentMap<String, Mapper> MAPPER_CACHE = new ConcurrentHashMap<>();

    static {
        DEFAULT_MAPPER = DozerBeanMapperBuilder.buildDefault();
    }

    private MapperUtil() {
    }

    /**
     * @param s   数据对象
     * @param clz 复制目标类型
     * @param <T>
     * @param <S>
     * @return
     * @Description: 单个对象的深度复制及类型转换，vo/domain , po
     */
    public static <T, S> T convert(S s, Class<T> clz) {
        if (s == null) {
            return null;
        }
        return DEFAULT_MAPPER.map(s, clz);
    }


    /**
     * @param s   数据对象
     * @param clz 复制目标类型
     * @param <T>
     * @param <S>
     * @return
     * @Description: list深度复制
     */
    public static <T, S> List<T> convert(List<S> s, Class<T> clz) {
        if (s == null) {
            return null;
        }
        List<T> list = new ArrayList<T>();
        for (S vs : s) {
            list.add(DEFAULT_MAPPER.map(vs, clz));
        }
        return list;
    }

    /**
     * @param s   数据对象
     * @param clz 复制目标类型
     * @param <T>
     * @param <S>
     * @return
     * @Description: Set深度复制
     */
    public static <T, S> Set<T> convert(Set<S> s, Class<T> clz) {
        if (s == null) {
            return null;
        }
        Set<T> set = new HashSet<T>();
        for (S vs : s) {
            set.add(DEFAULT_MAPPER.map(vs, clz));
        }
        return set;
    }

    /**
     * @param s   数据对象
     * @param clz 复制目标类型
     * @param <T>
     * @param <S>
     * @return
     * @Description: 数组深度复制
     */
    public static <T, S> T[] convert(S[] s, Class<T> clz) {
        if (s == null) {
            return null;
        }
        @SuppressWarnings("unchecked")
        T[] arr = (T[]) Array.newInstance(clz, s.length);
        for (int i = 0; i < s.length; i++) {
            arr[i] = DEFAULT_MAPPER.map(s[i], clz);
        }
        return arr;
    }

    /**
     * 拷贝非空且非空串属性
     *
     * @param source 数据源
     * @param target 指向源
     */
    public static void convertIgnoreNullAndBlank(Object source, Object target) {
        String key = source.getClass().getName() + "->" + target.getClass().getName() + ":nonullblank";
        Mapper mapper = MAPPER_CACHE.computeIfAbsent(key, k -> {
            DozerBeanMapperBuilder dozerBeanMapperBuilder = DozerBeanMapperBuilder.create();
            return dozerBeanMapperBuilder.withMappingBuilders(new BeanMappingBuilder() {
                @Override
                protected void configure() {
                    mapping(source.getClass(), target.getClass(), mapNull(false), mapEmptyString(false));
                }
            }).build();
        });
        mapper.map(source, target);
    }

    /**
     * 拷贝非空属性
     *
     * @param source 数据源
     * @param target 指向源
     */
    public static void convertIgnoreNull(Object source, Object target) {
        String key = source.getClass().getName() + "->" + target.getClass().getName() + ":nonull";
        Mapper mapper = MAPPER_CACHE.computeIfAbsent(key, k -> {
            DozerBeanMapperBuilder dozerBeanMapperBuilder = DozerBeanMapperBuilder.create();
            return dozerBeanMapperBuilder.withMappingBuilders(new BeanMappingBuilder() {
                @Override
                protected void configure() {
                    mapping(source.getClass(), target.getClass(), mapNull(false));
                }
            }).build();
        });
        mapper.map(source, target);
    }

}